To deploy, run the script like so:

./deploy.sh --region us-east-1 --role ROLE_ARN
